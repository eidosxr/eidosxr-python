# Auto-generated file - DO NOT EDIT
__version__ = "0.10.2"

